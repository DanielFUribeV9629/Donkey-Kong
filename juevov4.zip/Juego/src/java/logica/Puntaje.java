/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;
import java.sql.Date;
import java.text.SimpleDateFormat;
/**
 *
 * @author Estudiantes
 */
public class Puntaje {
    int id;
    int juego;
    int jugador;
    int descripcion;
    Date fecha;

    public int getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(int descripcion) {
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getJuego() {
        return juego;
    }

    public void setJuego(int juego) {
        this.juego = juego;
    }

    public int getJugador() {
        return jugador;
    }

    public void setJugador(int jugador) {
        this.jugador = jugador;
    }
    public Date getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        java.sql.Date sqlDate = java.sql.Date.valueOf(fecha);
        this.fecha =  sqlDate;
    }
}
