$(document).ready(inicio)
$(document).keydown(manejar_evento)

var puntaje = 0;

function inicio(){
	lienzo = $("#lienzo3")[0];
	contexto = lienzo.getContext("2d");
	buffer = document.createElement("canvas");
	kong = new kong();
	barriles = [new barril(),new barril(),new barril(),new barril(),new barril(),new barril(),new barril()];

	animar();
}

function animar(){
	buffer.width = lienzo.width;
	buffer.height = lienzo.height;
	contextoBuffer = buffer.getContext("2d");
	contextoBuffer.clearRect(0,0, buffer.width, buffer.height);
	
	kong.dibujar(contextoBuffer);
	kong.moverse();

	for(i=0; i<6;i++){
		barriles[i].dibujar(contextoBuffer);
		barriles[i].actualizar(i);
	}
	
	contexto.clearRect(0,0, lienzo.width, lienzo.height);
	contexto.drawImage(buffer, 0, 0);
	cambioPuntaje();
	
	setTimeout("animar()",20);
}

function manejar_evento(event){
	if (event.which == 39){
		kong.moverse("derecha");
	}
	if(event.which == 37){
		kong.moverse("izquierda");
	}
}


function kong(){
	this.x = 600;
	this.y = 550;
	this.img = [$("#kong0")[0],$("#kong1")[0],$("#kong2")[0],$("#kong3")[0],$("#kong4")[0],$("#kong5")[0],$("#kong6")[0],$("#kong7")[0]];
	this.sprite = 0;
	
	this.dibujar = function(ctx){
		ctx.drawImage(this.img[this.sprite], this.x, this.y);
	}

	this.moverse = function(accion){
		if (accion == "derecha") {
			this.x = this.x+15;
			
			if(this.sprite == 7){
				this.sprite = 0;
			}
			else{
				this.sprite = this.sprite + 1;
			}
		}
			if(accion == "izquierda"){
			this.x = this.x -15;
			if(this.sprite == 0){
				this.sprite = 7;
			}
			else{
				this.sprite = this.sprite - 1;
			}
		}
		if(this.x==-15 || this.x==-38){
		   this.x = lienzo.width-128;}else{
		   
		if(this.x == lienzo.width-113 || this.x == lienzo.width-90){
			this.x = 0;
		}
	}}
		
}

function getRandomArbitrary(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

function cambioPuntaje(){
	var imprimepuntaje = "Puntaje: " + puntaje;
	contexto.font ="30px Comic Sans MS";
	contexto.fillStyle = "white";
	contexto.fillText(imprimepuntaje, 10,30);
}

function barril(){
	this.x = getRandomArbitrary(0,92)*15;
	this.y = 0;
	this.vel = getRandomArbitrary(7,10);
	this.img = [$("#barril0")[0],$("#barril1")[0]];
	this.sprite = 0;

	this.dibujar = function(ctx){
		ctx.drawImage(this.img[this.sprite], this.x, this.y);
	}
	this.actualizar = function (numbar){
		this.y += this.vel;
		if(this.sprite == 1){
			this.sprite = 0;
		}
		else
		{
			this.sprite = 1;
		}
		colisionBarril(numbar);

		if (this.y + 170 >= lienzo.height) {
			this.x = getRandomArbitrary(0,92) * 15;
			this.y = -150;
			this.vel = getRandomArbitrary(7,10);
			puntaje += 1;

		} 
	}	
}

function colisionBarril(numbar2){
	if
		((((barriles[numbar2].x <= kong.x + 64) && (barriles[numbar2].x >= kong.x - 64)) ||
		(barriles[numbar2].x - 64 <= kong.x + 64) && (barriles[numbar2].x - 64 >= kong.x - 64) ||
		((barriles[numbar2].x + 64 >= kong.x - 64) && (barriles[numbar2].x + 64 <= kong.x + 64))) &&
		((barriles[numbar2].y) >= (kong.y - 62)))
		{
		alert("Su puntaje fue: " + puntaje);
		location.reload(true);
	}
}
