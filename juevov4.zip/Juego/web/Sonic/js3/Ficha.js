function aleatorio(piso, techo) {
    return Math.floor(Math.random() * (techo - piso + 1)) + piso;
}

function Ficha(x, y) {
    var opc = aleatorio(1, 100) % 2;
    if (opc == 1)
        this.img = $("#ficha_1")[0];
    else
        this.img = $("#ficha_2")[0];
    this.x = aleatorio(0, 920);
    this.y = aleatorio(1, 450);

    this.dibujar = function (ctx) {
        var img = this.img;
        ctx.drawImage(img, this.x, this.y);
    }
    this.actualizar = function () {
        this.x = (943 + this.x) % 943;
    }
}
