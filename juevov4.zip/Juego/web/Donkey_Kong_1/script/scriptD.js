
$(document).ready(inicio);
$(document).keydown(manejar_evento);
var puntaje=0; 
function inicio() {
	lienzo = $("#lienzo2")[0];
	contexto = lienzo.getContext("2d");
	buffer = document.createElement("canvas");
	donkey = new Donkey();
	barril = [new Barril(), new Barril(), new Barril(),new Barril()];
	animar();
}






function animar(){
	tiempo = 50;
	buffer.width = lienzo.width;
	buffer.height = lienzo.height;
	contextoBuffer = buffer.getContext("2d");
	
	contextoBuffer.clearRect(0, 0, buffer.width, buffer.height);
	donkey.dibujar(contextoBuffer);
	
	donkey.actualizarX();

	for (i = 0; i < barril.length; i++) {

		barril[i].dibujarB(contextoBuffer);
		barril.sprite =0;
        	barril[i].actualizarB();
        	if(donkey.colision(barril[i].x,barril[i].y)){
			barril[i].sprite =1;
			barril[i].dibujarB(contextoBuffer);
        		barril[i].y=0;
        		barril[i].x=aleatorio(0,1080);
			tiempo = 1000;
			setTimeout(function(){alert("Game Over");},75);
                        document.getElementById("puntaje").value = puntaje;
                        puntaje=0;
       }   
	   
	   barril[i].sprite =0;
	   
	}
	contexto.clearRect(0, 0, lienzo.width, lienzo.height);
	contexto.drawImage(buffer, 0, 0);
	cambioPuntaje();
	setTimeout("animar()", tiempo);
}

function manejar_evento(event){
	if (event.which == 39){
		donkey.actualizarX("derecha")
	}
	if (event.which == 37){
		donkey.actualizarX("izquierda")
	}
}
function aleatorio(piso, techo) {
    return Math.floor(Math.random() * (techo - piso + 1)) + piso;
}


function cambioPuntaje(){
	var imprimepuntaje = "Puntaje: " + puntaje;
	contexto.font ="30px Comic Sans MS";
	contexto.fillStyle = "white";
	contexto.fillText(imprimepuntaje, 10,30);
}

function Barril (x,y){

	var opc = aleatorio(2, 100) % 2;
	this.img = [$("#barril")[0], $("#exp")[0]];
	this.x = aleatorio(0, 1080);
    this.y = 0;
	this.velocidad = aleatorio(2,10);
	this.sprite =0;
	

	this.dibujarB = function(ctx) {
		var img = this.img[this.sprite];
		ctx.drawImage(this.img[this.sprite], this.x, this.y);
	}
	
	this.actualizarB = function() {
		this.y +=this.velocidad;
		if (this.y>600){
			this.x = aleatorio(0, 1080);
			puntaje++;
    		this.y = 0;
			this.velocidad = aleatorio(2,10);
		}
	}
}

function Donkey(){
	this.x = 500;
	this.y = 450;
	this.vel=10;
	this.pasod = 0;
    this.pasoi = 0;
	this.direccion = 0;
	this.sprite = 0;
	this.img = [[$("#d1")[0], $("#d2")[0]], [$("#i1")[0],$("#i2")[0]]];
	
	this.dibujar = function(ctx) {
		var img = this.img[this.direccion][this.sprite];
		ctx.drawImage(this.img[this.direccion][this.sprite], this.x, this.y);
		
  
	}	
	
	
	this.actualizarX = function(accion) {
		if (accion == "derecha" && this.x + 130 <= lienzo.width ){
		
            		this.x += this.vel;
			this.direccion = 0;
			this.sprite += 1;
			this.sprite = this.sprite % 2;
			
		}
		   if (accion == "izquierda" && this.x >=0) {
         
            		this.x -= this.vel;
			this.direccion = 1;
			this.sprite += 1;
			this.sprite = this.sprite % 2;
        }	
		
			
	
			
	}
	 this.colision = function (x, y) {
        var distancia = Math.sqrt(Math.pow((x - this.x), 2) + Math.pow((y - this.y), 2));
        if (distancia > this.img[0][0].height)
			
            return false;
        else
            return true;
    }
 }